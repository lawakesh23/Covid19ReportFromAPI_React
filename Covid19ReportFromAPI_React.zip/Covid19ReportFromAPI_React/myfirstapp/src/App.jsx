import React from "react";
import Orderlist from "./Orderlist";
import InputForm from './InputForm';
import Covid19Data from "./Components/Covid19Data";
import  "./Components/Covid19Data.css";

function App(){
    return(
        <>
        {/* <Orderlist/>
        <hr/>
        <InputForm/>
        <hr/> */}
        <Covid19Data/>
        </>
    );
}

export default App;